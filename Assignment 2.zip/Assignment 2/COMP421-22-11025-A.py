import rsa

#Taking input
x = input("Enter a string to be tested: ")

#Assigning keys and showing
keyPublic, keyPrivate = rsa.newkeys(512)

print("Public key is: ",keyPublic)

print("Private key is: ", keyPrivate)

#Showing string to be tested
print("The text to be encrypted is: ", x) 

#Encryption Part
def encryptingData(x):
    
    #RSA algorithm usage for encryption
    x = x.encode('utf8')
    
    finalEncryption = rsa.encrypt(x, keyPublic)
    
    return finalEncryption

finalEncryption = encryptingData(x)

#Input encryption
print("Encrypted text is as follow: = %s" %(finalEncryption))   

#Decryption Part
def decryptingData(finalEncryption):
    
    #RSA algorithm usage for encryption
    finalDecryption = rsa.decrypt(finalEncryption, keyPrivate)
    
    return finalDecryption.decode("utf-8")

finalDecryption = decryptingData(finalEncryption)

#Input Decryption
print("Decrypted text is = %s" %(finalDecryption))   
